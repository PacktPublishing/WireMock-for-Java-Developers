# Movies RestFul WebService

## How to Run the app?

- Run the below command in your machine. You must have java8 or higher to run this application.

```
java -jar movies-restful-service.jar
```

## Swagger Link

The below link will launch the swagger of the movies-restful-web-service.

http://localhost:8081/movieservice/swagger-ui.html#/
