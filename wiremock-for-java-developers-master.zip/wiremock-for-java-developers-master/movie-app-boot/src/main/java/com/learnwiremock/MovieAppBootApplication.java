package com.learnwiremock;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieAppBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieAppBootApplication.class, args);
	}

}
